该资源包含了一个或多个贡献者提供的重要贡献, 故在此readme文件集合.

# 全角符号字宽修复
修复了Minecraft原版的一个bug，即中文标点符号占位仅为一格。

- 原作者：3TUSK
- 原帖地址：http://blog.tritusk.info/index.php/archives/8/
- Github：https://github.com/Team-AbCiv/FullwidthPunctuationFix
