# 软盘驱动器

![Going round and round and...](oredict:oc:diskDrive)

用于读取[软盘](../item/floppy.md). 初期很有用，因为低级别的 [机箱](case1.md)没有软盘槽

你还需要操作系统如OpenOS，Plan9K，MineOS等，来启动[电脑](../general/computer.md).

[OpenOS](../general/openOS.md) 安装盘可以用空的 [软盘](../item/floppy.md) 和[OC手册](../item/manual.md)合成.

也可以被安装在机器人[robots](robot.md)里面来允许插入 [软盘](../item/floppy.md)

在没有网卡的时候这是非常有用的数据传输方式了

可以 通过shift（蹲） + 右键，可以不打开软驱GUI装卸软盘
