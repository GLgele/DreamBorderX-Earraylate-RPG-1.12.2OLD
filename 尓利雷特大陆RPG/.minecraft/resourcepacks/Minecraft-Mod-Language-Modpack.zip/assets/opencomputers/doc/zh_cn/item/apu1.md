# APU

![Awesomest Probability Unifier.](oredict:oc:apu1)

[CPU](cpu1.md)和[显卡](graphicsCard1.md)的结合，AMD（农企）首创. 可以省一个格子，当然了这块显卡性能肯定没有独显厉害www