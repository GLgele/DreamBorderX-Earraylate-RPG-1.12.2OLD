# 磁盘

![World. RIP Terry Pratchett.](oredict:oc:materialDisk)

基础组件，用于合成软盘和硬盘
