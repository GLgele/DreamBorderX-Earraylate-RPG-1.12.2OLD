# Redstone Card

![Seeing red.](oredict:oc:redstoneCard1)

红石卡让[电脑](../general/computer.md) 可以读写相邻方块的红石信号.输入信号变化时, 信号将输入[电脑](../general/computer.md).

如果有mod可以提供多个红石信号捆绑同时传递的能力, 如Redlogic，MFR，Redpower; 或者是提供了无线红石传递的mod，比如 WR-CBE，或者Slimevoid's Wireless，那么将有一个二级红石卡来处理和他们的通讯.

输入面是相对于机箱，机器人，机架自身的，也就是说，当你站在电脑的前面（正面）的时候，`sides.right` 指的是你左边（你面对的方向左边）.
