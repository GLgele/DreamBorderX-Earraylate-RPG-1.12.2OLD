datLax' OnlyWater Shader

THANK YOU FOR DOWNLOADING MY SHADERPACK!

Also special thanks to Edi ZockLP for cleaning up my code!

If you have questions or bugs you want to report, please write on my thread at minecraftforum.net:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/2381727-shader-pack-datlax-onlywater-only-water

Have fun!