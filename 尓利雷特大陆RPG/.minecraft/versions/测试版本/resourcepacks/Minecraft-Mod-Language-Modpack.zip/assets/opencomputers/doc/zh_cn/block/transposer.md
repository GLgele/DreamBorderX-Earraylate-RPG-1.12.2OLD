# Transposer

![Such a poser.](oredict:oc:transposer)

转置器连接了红石控制的漏斗和[机器人](robot.md), 允许 [电脑](../general/computer.md)-控制液体和物品在相邻方块转移.

*本方块不自带物品栏.*

本方块具有探测容器物品的能力
