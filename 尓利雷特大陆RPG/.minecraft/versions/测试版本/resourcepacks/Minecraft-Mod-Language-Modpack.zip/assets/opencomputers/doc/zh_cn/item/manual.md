# Manual

![A good read.](oredict:oc:manual)

嗯，这是OC手册，就像是读wiki一样

左键点击链接可以导航到对应位置，跳跃或者右击返回上一级，Esc退出

由loveyanbei(https://github.com/loveyanbei) 汉化

如果有问题可以访问 http://ocdoc.cil.li 查看wiki

对翻译有疑问可以自行pull request

如果mod有bug，可到bug tracker 提问 https://github.com/MightyPirates/OpenComputers/issues

![Your new best friend.](opencomputers:doc/img/manual.png)
