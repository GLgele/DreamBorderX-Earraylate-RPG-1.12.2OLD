# Texture Picker

![What do you mean, it's just a re-skin?](oredict:oc:texturePicker)

纹理拾取器用于制作3d打印的模型 [3D printer](../block/printer.md). 可以通过蹲下+右键拾取世界中方块使用的纹理, 注意: 某些渲染特殊的方块,比如箱子，不起作用。
